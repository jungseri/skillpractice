# CSSeffectsSnippets

https://emilkowalski.github.io/css-effects-snippets/

## Usage

Click on the animation to copy it to your clipboard

## How to start?
Use yarn
```
yarn 

yarn serve
```
or npm
```
npm install

npm run serve
```

## How to contribute?

 - Fork it
 - Create your branch: `git checkout -b my-feature`
 - Commit: `git commit -am 'Add new feature'`
 - Push to your branch: `git push origin my-new-feature`
 - Submit a PR 🎉
